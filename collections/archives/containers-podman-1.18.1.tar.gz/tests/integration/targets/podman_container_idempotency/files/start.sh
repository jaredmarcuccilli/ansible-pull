#!/bin/sh

s=${1:-"3h"}
sleep "$s"

