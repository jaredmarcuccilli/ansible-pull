# Rsyslog Provider

This sub-tree contains the fedora.linux_system_roles.private_logging_subrole_rsyslog implementation.

Rsyslog specific configuration will be described here if any.
