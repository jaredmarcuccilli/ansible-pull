#!/usr/bin/env bash
echo -n "Installed."
